$(document).ready(function() {
	$("img").click(function () {
	
		$(".sect").addClass('hidden');
		$(".sect2").removeClass('hidden');

	});

});
$('a').click(function(e){
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 700);
    return false;
});

