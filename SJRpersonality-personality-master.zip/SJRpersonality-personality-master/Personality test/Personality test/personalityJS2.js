$(document).ready(function() {
	$("img").click(function() {
	
		$(".sect").addClass('hidden');
		$(".sect2").removeClass('hidden');

	});
	$("img2").click(function() {
	
		$(".sect2").addClass('hidden');
		$(".sect3").removeClass('hidden');

	});
	$("img3").click(function() {
	
		$(".sect3").addClass('hidden');
		$(".sect4").removeClass('hidden');

	});
	$("img4").click(function() {
	
		$(".sect4").addClass('hidden');
		$(".sect5").removeClass('hidden');

	});
	$("img5").click(function() {
	
		$(".sect5").addClass('hidden');
		$(".sect6").removeClass('hidden');

	});
	$("img6").click(function() {
	
		$(".sect6").addClass('hidden');
		$(".sect7").removeClass('hidden');

	});
	$("img7").click(function() {
	
		$(".sect7").addClass('hidden');
		$(".sect8").removeClass('hidden');

	});
	$("img8").click(function() {
	
		$(".sect8").addClass('hidden');
		$(".sect9").removeClass('hidden');

	});
	$("img9").click(function() {
	
		$(".sect9").addClass('hidden');
		$(".sect10").removeClass('hidden');

	});

});
$('a').click(function(e){
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 700);
    return false;
});

